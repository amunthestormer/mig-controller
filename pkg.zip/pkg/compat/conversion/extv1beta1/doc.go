package extv1beta1

// +k8s:conversion-gen=k8s.io/api/extensions/v1beta1
// +k8s:conversion-gen-external-types=k8s.io/api/apps/v1
