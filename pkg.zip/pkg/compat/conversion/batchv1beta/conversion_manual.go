package batchv1beta

import "k8s.io/apimachinery/pkg/runtime"

var (
	localSchemeBuilder = runtime.SchemeBuilder{}
)
